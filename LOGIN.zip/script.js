var myweb = angular.module("myweb",[]);
myweb.controller("Login", function ($scope){
	//funcion Inicio de Sesion
	$scope.nombre = "LUIS"
	$scope.contrasena = "ADIOS"
	

	$scope.Inicio = function(a,b){
		if (a == $scope.nombre && b == $scope.contrasena) {
			window.open("https://www.spotify.com/gt/","_parent")
		}else{
			swal("usuario incorrecto o contraseña incorrecta")
			}
		}
});